# Welcome to the ProjectFrelard wiki!

This wiki contains developer documentation (see the pages listed to right). 
You are encouraged to use them and also contribute to make them better.  

Use [Issues](https://github.com/tableau/ProjectFrelard/issues) to log any problems or bugs you encounter in the docs or example code. 

![tflex the trex](https://github.com/tableau/ProjectFrelard/blob/master/assets/tflx.png)  

***

